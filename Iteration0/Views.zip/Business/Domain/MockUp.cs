﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Iteration0.Business.Domain
{
    public class MockUp
    {
        //Domain value object (no persistence)
    }
}