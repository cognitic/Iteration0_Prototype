﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Iteration0.Business.Interfaces;

namespace Iteration0.Business.Services
{
    public class UserService : IUserService
    {

    }
}