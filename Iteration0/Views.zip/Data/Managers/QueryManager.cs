﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Iteration0.Data.Managers
{
    public class QueryManager
    {
        //DB Read Only Fast Data Provider
    }
}